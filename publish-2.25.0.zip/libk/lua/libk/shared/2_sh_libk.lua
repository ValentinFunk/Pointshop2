LibK = {}

LibK.Debug = false
LibK.LogLevel = 4 --Requires Debug
LibK.LogSQL = false
