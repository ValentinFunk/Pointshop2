GLib.Rendering.Buffers.BufferFlags = GLib.Enum (
	{
		None    = 0,
		Dynamic = 1
	}
)