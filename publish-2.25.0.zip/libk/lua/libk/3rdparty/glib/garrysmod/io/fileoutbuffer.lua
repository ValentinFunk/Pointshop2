local self = {}
GLib.FileOutBuffer = GLib.MakeConstructor (self, GLib.OutBuffer)
