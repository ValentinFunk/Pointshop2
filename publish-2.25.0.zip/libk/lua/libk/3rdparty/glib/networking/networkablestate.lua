GLib.Networking.NetworkableState = GLib.Enum (
	{
		Unsynchronized = 0,
		Synchronizing  = 1,
		Synchronized   = 2
	}
)