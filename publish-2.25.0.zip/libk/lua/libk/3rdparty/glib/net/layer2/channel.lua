local self = {}
GLib.Net.Layer2.Channel = GLib.MakeConstructor (self, GLib.Net.IChannel)