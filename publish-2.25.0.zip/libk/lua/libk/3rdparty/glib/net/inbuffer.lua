local self = {}
GLib.Net.InBuffer = GLib.MakeConstructor (self, GLib.InBuffer)

function self:ctor ()
end