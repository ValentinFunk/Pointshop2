function GLib.Net.DispatchPacket (destinationId, channelName, packet)
	GLib.Error ("GLib.Net.DispatchPacket : Not implemented.")
end

function GLib.Net.RegisterChannel (channelName, handler)
	GLib.Error ("GLib.Net.RegisterChannel : Not implemented.")
end

function GLib.Net.UnregisterChannel (channelName)
	GLib.Error ("GLib.Net.UnregisterChannel : Not implemented.")
end

function GLib.Net.IsChannelOpen (channelName)
	GLib.Error ("GLib.Net.IsChannelOpen : Not implemented.")
end