GLib.WordType = GLib.Enum (
	{
		None         = 0,
		Alphanumeric = 1,
		Whitespace   = 2,
		LineBreak    = 3,
		Other        = 4,
	}
)