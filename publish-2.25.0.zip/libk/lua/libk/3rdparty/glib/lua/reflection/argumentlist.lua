local self = {}
GLib.Lua.ArgumentList = GLib.MakeConstructor (self)

function self:ctor ()
	
end