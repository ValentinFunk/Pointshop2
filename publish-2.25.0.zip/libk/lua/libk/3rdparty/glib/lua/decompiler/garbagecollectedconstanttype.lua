GLib.Lua.GarbageCollectedConstantType = GLib.Enum (
	{
		Function = 0,
		Table    = 1,
		Int64    = 2,
		UInt64   = 3,
		Complex  = 4,
		String   = 5
	}
)