local self = {}
GLib.IServer = GLib.MakeConstructor (self)